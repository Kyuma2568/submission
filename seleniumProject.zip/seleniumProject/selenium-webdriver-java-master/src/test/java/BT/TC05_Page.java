package BT;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class TC05_Page {
    private WebDriver driver;

    // Declare element selector value here
    private By myAccountLinkSelector = By.linkText("MY ACCOUNT");
    private By createAnAccountLinkSelector = By.linkText("CREATE AN ACCOUNT");
    // Add selectors for new user information fields
    private By registerButtonSelector = By.cssSelector("button[title='Register']");
    private By registrationMessageSelector = By.cssSelector(".success-msg");
    private By tvMenuSelector = By.linkText("TV");
    private By addToWishlistLgLcdSelector = By.xpath("//h2[a='LG LCD']/following-sibling::div//a[@title='Add to Wishlist']");
    private By shareWishlistButtonSelector = By.cssSelector("button[title='Share Wishlist']");
    // Add selectors for email and message fields
    private By sharedWishlistMessageSelector = By.cssSelector(".success-msg");

    // Constructor with required parameter as a WebDriver instance
    public TC05_Page(WebDriver driver) {
        this.driver = driver;
    }

    // Methods to interact with the elements on the page
    public void clickOnMyAccountLink() {
        driver.findElement(myAccountLinkSelector).click();
    }

    public void clickCreateAnAccountLink() {
        driver.findElement(createAnAccountLinkSelector).click();
    }

    public void fillNewUserInfo() {
        // Fill new user information here
    }

    public void clickRegister() {
        driver.findElement(registerButtonSelector).click();
    }

    public String getRegistrationMessage() {
        return driver.findElement(registrationMessageSelector).getText();
    }

    public void goToTvMenu() {
        driver.findElement(tvMenuSelector).click();
    }

    public void addToWishlistLgLcd() {
        driver.findElement(addToWishlistLgLcdSelector).click();
    }

    public void clickShareWishlist() {
        driver.findElement(shareWishlistButtonSelector).click();
    }

    public void enterEmailAndMessage() {
        // Enter email and message here
    }

    public String getSharedWishlistMessage() {
        return driver.findElement(sharedWishlistMessageSelector).getText();
    }
}
